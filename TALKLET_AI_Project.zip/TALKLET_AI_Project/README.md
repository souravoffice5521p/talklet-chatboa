# TALKLET AI — Mini RAG Chatbot

**Project title:** TALKLET AI – An Intelligent Document-Based Question Answering Chatbot Using Retrieval-Augmented Generation (RAG)

This project follows the practical assignment requirements:
- Streamlit chatbot interface
- Upload one PDF or TXT document
- Extract and split document text into chunks
- Free Sentence Transformers embeddings
- FAISS similarity search
- Local Ollama language model
- Answers grounded in retrieved document text
- Source text displayed with each answer
- Prompt instructs the model not to invent missing information

## 1. Requirements

- Python 3.10 or 3.11 recommended
- Internet connection for installing Python packages and downloading the embedding model the first time
- Ollama installed and running locally
- At least one Ollama model downloaded

No paid API key is required.

## 2. Install and run

Open a terminal in this project folder.

### Windows

```bash
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Install Ollama from https://ollama.com/download and then, in a terminal, download a model:

```bash
ollama pull llama3.2:3b
```

Start Ollama if it is not already running. Then launch the chatbot:

```bash
streamlit run app.py
```

Streamlit will show a local address, usually http://localhost:8501. Open it in your browser.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ollama pull llama3.2:3b
streamlit run app.py
```

If your computer has limited memory, choose a smaller model supported by Ollama and enter its exact name in the sidebar.

## 3. How to use

1. Open TALKLET AI in your browser.
2. Upload a text-based PDF or TXT file.
3. Click **Process document**.
4. Wait until the document is indexed.
5. Enter a question in the chat box.
6. Expand **View source text** to inspect the retrieved passages.

Scanned/image-only PDFs may not contain extractable text. Run OCR on such a PDF first, or use a text-based PDF/TXT file.

## 4. Five test questions

Use the included `sample_document.txt` for the demonstration.

1. What is solar energy?
2. Name two benefits of solar energy.
3. What is the purpose of a solar inverter?
4. What factors affect the output of a solar panel?
5. What is the population of India according to this document?  
   Expected behaviour: TALKLET AI should say it could not find this information in the uploaded document.

Record the actual answers produced by your local model and take screenshots for submission. Do not present expected answers as model-generated results.

## 5. Project workflow

Document upload → Text extraction → Chunking → Embedding generation → FAISS index → Relevant chunk retrieval → Ollama response generation → Answer and source display.

## 6. Main libraries

- `streamlit`: user interface
- `pypdf`: PDF text extraction
- `sentence-transformers`: free text embeddings
- `faiss-cpu`: vector similarity search
- `ollama`: local language model service (installed separately)
- `requests`: communicate with Ollama's local HTTP API
- `numpy`: numerical arrays

## 7. Important notes

- The app sends the retrieved document passages and question to the Ollama service running on your computer.
- The default model is `llama3.2:3b`. You can change it in the sidebar if another model is installed.
- Similarity scores help show which chunks were retrieved; they are not guarantees that an answer is correct.
- For the practical demonstration, test both answerable and unanswerable questions.
