import os
import tempfile
from pathlib import Path

import streamlit as st
import requests
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

APP_TITLE = "TALKLET AI"
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
DEFAULT_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

st.set_page_config(page_title=APP_TITLE, page_icon="💬", layout="wide")

@st.cache_resource(show_spinner="Loading embedding model...")
def load_embedding_model():
    return SentenceTransformer(EMBEDDING_MODEL)

def extract_text(uploaded_file):
    name = uploaded_file.name.lower()
    if name.endswith(".pdf"):
        reader = PdfReader(uploaded_file)
        pages = []
        for page_number, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                pages.append(f"[Page {page_number}]\n{text}")
        return "\n\n".join(pages)
    if name.endswith(".txt"):
        raw = uploaded_file.getvalue()
        for encoding in ("utf-8", "utf-8-sig", "latin-1"):
            try:
                return raw.decode(encoding)
            except UnicodeDecodeError:
                continue
        raise ValueError("Could not decode this TXT file.")
    raise ValueError("Please upload a PDF or TXT file.")

def chunk_text(text, chunk_size=900, overlap=150):
    text = " ".join(text.split())
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end == len(text):
            break
        start = max(0, end - overlap)
    return chunks

def build_index(chunks, model):
    vectors = model.encode(
        chunks,
        convert_to_numpy=True,
        normalize_embeddings=True,
        show_progress_bar=False
    ).astype("float32")
    index = faiss.IndexFlatIP(vectors.shape[1])
    index.add(vectors)
    return index

def retrieve(question, chunks, index, model, k=4):
    query_vector = model.encode(
        [question],
        convert_to_numpy=True,
        normalize_embeddings=True
    ).astype("float32")
    count = min(k, len(chunks))
    scores, ids = index.search(query_vector, count)
    results = []
    for score, idx in zip(scores[0], ids[0]):
        if idx >= 0:
            results.append((float(score), chunks[int(idx)]))
    return results

def ask_ollama(question, retrieved_chunks, model_name):
    context = "\n\n---\n\n".join(
        f"Source {i + 1}:\n{chunk}" for i, (_, chunk) in enumerate(retrieved_chunks)
    )
    prompt = f"""You are TALKLET AI, a document-grounded assistant.

Answer the user's question using ONLY the CONTEXT below.
Rules:
1. Do not use outside knowledge or guess.
2. If the context does not contain the answer, say:
   "I could not find this information in the uploaded document."
3. Keep the answer clear and concise.
4. Do not claim that something is in the document unless the context supports it.

CONTEXT:
{context}

QUESTION:
{question}

ANSWER:"""

    response = requests.post(
        f"{OLLAMA_URL}/api/generate",
        json={"model": model_name, "prompt": prompt, "stream": False},
        timeout=180
    )
    response.raise_for_status()
    return response.json().get("response", "").strip()

def ollama_models():
    response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
    response.raise_for_status()
    return [m.get("name", "") for m in response.json().get("models", [])]

st.markdown(
    """
    <div style="padding: 1.2rem 1.4rem; border-radius: 16px;
                background: linear-gradient(110deg,#172554,#4338ca); color:white;">
      <h1 style="margin:0;">💬 TALKLET AI</h1>
      <p style="margin:.35rem 0 0 0;">Your Documents. Your Questions. Smart Answers.</p>
    </div>
    """,
    unsafe_allow_html=True
)
st.write("Upload a PDF or TXT document, then ask questions that are answered from its content.")

with st.sidebar:
    st.header("Settings")
    model_name = st.text_input("Ollama model", value=DEFAULT_MODEL)
    top_k = st.slider("Number of source chunks", min_value=1, max_value=6, value=4)
    st.caption("The first run downloads the free embedding model. Ollama runs locally.")

    st.divider()
    st.subheader("Setup check")
    if st.button("Check Ollama connection"):
        try:
            models = ollama_models()
            st.success("Ollama is running.")
            if models:
                st.write("Installed models:", ", ".join(models))
            else:
                st.warning("Ollama is running, but no models are installed.")
        except Exception as exc:
            st.error(f"Could not connect to Ollama: {exc}")

uploaded_file = st.file_uploader("Upload your document", type=["pdf", "txt"])

if "chunks" not in st.session_state:
    st.session_state.chunks = []
if "index" not in st.session_state:
    st.session_state.index = None
if "doc_name" not in st.session_state:
    st.session_state.doc_name = ""
if "messages" not in st.session_state:
    st.session_state.messages = []

if uploaded_file is not None:
    if st.button("Process document", type="primary"):
        try:
            with st.spinner("Reading and indexing your document..."):
                extracted = extract_text(uploaded_file)
                chunks = chunk_text(extracted)
                if not chunks:
                    st.error("No readable text was found. If this is a scanned PDF, run OCR first.")
                else:
                    embedding_model = load_embedding_model()
                    index = build_index(chunks, embedding_model)
                    st.session_state.chunks = chunks
                    st.session_state.index = index
                    st.session_state.doc_name = uploaded_file.name
                    st.session_state.messages = []
                    st.success(f"Document ready: {len(chunks)} text chunks created.")
        except Exception as exc:
            st.error(f"Could not process document: {exc}")

if st.session_state.index is not None:
    st.info(f"Active document: **{st.session_state.doc_name}**")
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("sources"):
                with st.expander("View source text"):
                    for i, source in enumerate(message["sources"], start=1):
                        st.markdown(f"**Source {i}**")
                        st.caption(f"Similarity score: {source['score']:.3f}")
                        st.write(source["text"])

    question = st.chat_input("Ask a question about your document...")
    if question:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant"):
            try:
                with st.spinner("Finding relevant text and preparing an answer..."):
                    embedding_model = load_embedding_model()
                    found = retrieve(
                        question,
                        st.session_state.chunks,
                        st.session_state.index,
                        embedding_model,
                        top_k
                    )
                    answer = ask_ollama(question, found, model_name)
                st.markdown(answer)
                source_data = [{"score": score, "text": text} for score, text in found]
                with st.expander("View source text"):
                    for i, source in enumerate(source_data, start=1):
                        st.markdown(f"**Source {i}**")
                        st.caption(f"Similarity score: {source['score']:.3f}")
                        st.write(source["text"])
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": answer,
                    "sources": source_data
                })
            except requests.exceptions.ConnectionError:
                st.error("Cannot reach Ollama. Start Ollama and make sure the selected model is installed.")
            except requests.exceptions.HTTPError as exc:
                st.error(f"Ollama returned an error: {exc}. Check the model name.")
            except Exception as exc:
                st.error(f"Something went wrong: {exc}")

    if st.button("Clear chat"):
        st.session_state.messages = []
        st.rerun()
else:
    st.warning("Upload a document and click **Process document** to start chatting.")
